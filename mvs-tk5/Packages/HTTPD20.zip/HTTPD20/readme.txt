This archive contains a HTTP Server (HTTPD) for use with MVS 38J (TK4- or TK5).

HTTP servers are used to deliver static web pages and other resources (icons, pictures, etc) to a web browesr (Chrome, Firefox, Edge, etc).

HTTP servers are also used to deliver dynamic content (think data driven pages) which we also support via LINK of external modules.  

Static documents can be stored in UFS, an emulated Unix "like" File System, or Partitioned Datasets (PDS) allocated to DD names in the HTTPD JCL that match the document extension.  An example would be index.html which you would store as member INDEX in a PDS that is allocated to the HTML DD name.

Example:
//HTML     DD DISP=SHR,DSN=HLQ.HTTPD.HTML

where HLQ is your high-level-qualifier for your datasets.  See httpd.jcl for complete sample.

The socket interface used by the HTTPD server is the DYN75 interface.  Native socket support doesn't exist in legacy MVS38J/TK4-.  If you attempt to execute the HTTPD server on some newer MVS, like z/OS, you'll likely experience S0C1 or S0C4 abends as a result.

Files in this archive:
httpd20.aws          Hercules Emulated Tape, vol=ser=HTTP20
httpd.jcl            Sample JCL to execute the HTTPD server as a batch job.
httpd.proc           Sample JCL to execute the HTTPD server as a started task. Add to your SYS2.PROCLIB dataset.
loadtape.jcl         Sample JCL to load the httpd20.aws to SYS2.HTTPD.* datasets. <=== Do this first.
readme.txt           The file you're reading right now.

Note: The default dataset for the HTTPD steplib is SYS2.HTTPD.LINKLIB . 
You *should not* need to APF authorize this dataset if you will be running the HTTPD server as a started task. 
The HTTPD server will attempt to use SVC 244 to dynamically authorize itself at startup. 
You can add the SYS2.HTTPD.LINKLIB to the IEAAPF00 member of SYS1.PARMLIB should you so desire.

Example IEAAPF00:
 SYS1.VTAMLIB MVSRES,      
 SYS2.HTTPD.LINKLIB xxxxxx 
Be sure to replace the xxxxxx with the actual volser for the SYS2.HTTPD.LINKLIB dataset and reboot TK4- to activate the change.

To access the JES spool via the HTTPD server you should use your web browser with a url like 
http://127.0.0.1:8080/jesst.html

Once you have a JES Status page displayed you should be able to right-click on the table rows and get a context menu for the job on that table row.  The context menu has options for:
Display DD List
Download To File
View in Browser
Cancel jobname jobid
Purge jobname jobid

Operator Commands:
/P HTTPD (or whatever your HTTPD STC or jobname is) will terminate the HTTPD server.
/F HTTPD,D P display the listen ports used by the HTTPD server.
/F HTTPD,D T display task running in the HTTPD server.

Sample output from the HTTPD server:
 7.01.00 STC  568  IEF403I HTTPD - STARTED - TIME=07.01.00                                                            
 7.01.00 STC  568  +HTTPD000I HTTPD Server 2.0.0 starting                                                             
 7.01.00 STC  568  HTTPD011I HTTPD was APF authorized via SVC 244                                                     
 7.01.00 STC  568  HTTPD013I STEPLIB is now APF authorized                                                            
 7.01.00 STC  568  HTTPD048I Login required for (CGI,GET) request                                                     
 7.01.00 STC  568  HTTPD025I Time zone offset set to GMT -05:00:00                                                    
 7.01.00 STC  568  HTTPD032I Listening for HTTP request on port 8080                                                  
 7.01.00 STC  568  FTPD0005I Listening for FTP  request on port 8021                                                  
 7.01.00 STC  568  HTTPD046I Disk#0 File System on DD UFSDISK0 READ/WRITE                                             
 7.01.00 STC  568  HTTPD001I Server is READY                                                                          
 7.01.00 STC  568  HTTPD061I STARTING socket thread  TCB(9AD580) TASK(169FC8) MGR(152C88) CRT(152940)                 
 7.01.00 STC  568  HTTPD061I STARTING worker(1526B8) TCB(9AD058) TASK(17DFC8) MGR(152C88) CRT(152330)                 
 7.01.00 STC  568  HTTPD061I STARTING worker(1525B8) TCB(99FC18) TASK(18EFC8) MGR(152C88) CRT(152128)                 
 7.01.00 STC  568  HTTPD061I STARTING worker(152538) TCB(99F8E8) TASK(19FFC8) MGR(152C88) CRT(17BDC8) 
...

/f httpd,d p                                                                                                           
 7.51.53 STC  568  HTTPD100I CONS(3) "D P"                                                                            
 7.51.53 STC  568  HTTPD102I HTTPD server listening on port 8080                                                      
 7.51.53 STC  568  HTTPD102I FTPD  server listening on port 8021
...

/p httpd                                                                                                               
 7.52.41 STC  568  HTTPD100I CONS(3) STOP                                                                             
 7.52.41 STC  568  HTTPD002I Server is QUIESCE                                                                        
 7.52.41 STC  568  HTTPD060I SHUTDOWN socket thread  TCB(9AD580) TASK(169FC8) MGR(152C88) CRT(152940)                 
 7.52.42 STC  568  HTTPD060I SHUTDOWN worker(1671C0) TCB(99D9D8) TASK(23BFC8) MGR(152C88) CRT(169838)                 
 7.52.42 STC  568  HTTPD060I SHUTDOWN worker(167C88) TCB(99E1F8) TASK(214FC8) MGR(152C88) CRT(169AC0)                 
 7.52.43 STC  568  HTTPD060I SHUTDOWN worker(152060) TCB(99E608) TASK(1FFFC8) MGR(152C88) CRT(169CC8)                 
 7.52.43 STC  568  HTTPD060I SHUTDOWN worker(167D48) TCB(99E938) TASK(1EAFC8) MGR(152C88) CRT(167740)                 
 7.52.43 STC  568  HTTPD060I SHUTDOWN worker(167E88) TCB(99EC68) TASK(1D7FC8) MGR(152C88) CRT(165780)                 
 7.52.43 STC  568  HTTPD060I SHUTDOWN worker(1635C8) TCB(99EEB8) TASK(1C4FC8) MGR(152C88) CRT(167240)                 
 7.52.43 STC  568  HTTPD060I SHUTDOWN worker(152538) TCB(99F8E8) TASK(19FFC8) MGR(152C88) CRT(17BDC8)                 
 7.52.43 STC  568  HTTPD060I SHUTDOWN worker(1525B8) TCB(99FC18) TASK(18EFC8) MGR(152C88) CRT(152128)                 
 7.52.43 STC  568  HTTPD060I SHUTDOWN worker(1526B8) TCB(9AD058) TASK(17DFC8) MGR(152C88) CRT(152330)                 
 7.52.45 STC  568  HTTPD047I Terminating File System                                                                  
 7.52.45 STC  568  HTTPD002I Server is SHUTDOWN                                                                       
 7.52.45 STC  568  IEF404I HTTPD - ENDED - TIME=07.52.45                                                              
 7.52.45 STC  568  $HASP395 HTTPD    ENDED

